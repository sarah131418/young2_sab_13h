import { useState } from 'react'
import './App.css'
import StarIcon from '@mui/icons-material/Star';
import StarBorderIcon from '@mui/icons-material/StarBorder';

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div class="split left">
        <h2 class="name">MATEO GARZÓN RESTREPO</h2>
        <p class="title">Desarrollador full stack senior</p>
        <div class="mini_box">
          <h2 class="sub_title">Perfil</h2>
        </div>
        <p class="text_title">Email</p>
        <p class="general_txt">grteo10@gmail.com</p>
        <p class="text_title">Telefono</p>
        <p class="general_txt">3219120519</p>
        <div class="mini_box">
          <h2 class="sub_title">Habilidades</h2>
        </div>
        <div class="number">
          <li class="li_text">C# <div style={{ float: 'right' }}><StarIcon /><StarIcon /><StarIcon /><StarIcon /><StarBorderIcon /></div></li>
          <li class="li_text">SQL <div style={{ float: 'right' }}><StarIcon /><StarIcon /><StarIcon /><StarIcon /><StarBorderIcon /></div></li>
          <li class="li_text">React <div style={{ float: 'right' }}><StarIcon /><StarIcon /><StarIcon /><StarIcon /><StarBorderIcon /></div></li>
          <li class="li_text">NodeJs <div style={{ float: 'right' }}><StarIcon /><StarIcon /><StarIcon /><StarBorderIcon /><StarBorderIcon /></div></li>
          <li class="li_text">.NET <div style={{ float: 'right' }}><StarIcon /><StarIcon /><StarIcon /><StarIcon /><StarBorderIcon /></div></li>
          <li class="li_text">.NET Core <div style={{ float: 'right' }}><StarIcon /><StarIcon /><StarIcon /><StarIcon /><StarBorderIcon /></div></li>
          <li class="li_text">GIT <div style={{ float: 'right' }}><StarIcon /><StarIcon /><StarIcon /><StarIcon /><StarBorderIcon /></div></li>
          <li class="li_text">MVC5 <div style={{ float: 'right' }}><StarIcon /><StarIcon /><StarIcon /><StarIcon /><StarIcon /></div></li>
          <li class="li_text">JavaScript <div style={{ float: 'right' }}><StarIcon /><StarIcon /><StarIcon /><StarIcon /><StarBorderIcon /></div></li>
          <li class="li_text">JQuery <div style={{ float: 'right' }}><StarIcon /><StarIcon /><StarIcon /><StarIcon /><StarBorderIcon /></div></li>
          <li class="li_text">API Rest <div style={{ float: 'right' }}><StarIcon /><StarIcon /><StarIcon /><StarIcon /><StarBorderIcon /></div></li>
        </div>
      </div>

      <div class="split right">
        <p class="intro">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
        <hr class="solid" />
        <h2 class="sub_title_w">Experiencia</h2>
        <hr class="solid" />

        <div class='contenedor'>
          <div class="split2 left2">
            <br />
            <p class='general_txt2'>2022-01 </p>
            <p class='general_txt2'>- actualmente</p>
          </div>
          <div class="split2 right2">
            <h2 class='decrip_title2'>Desarrollador de software senior</h2>
            <p class="title2">Transfiriendo S.A Bogotá D.C</p>
            <p >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
            <li>daasd</li>
            <li>daasd</li>
            <li>daasd</li>
            <li>daasd</li>
            <li>daasd</li>
            <li>daasd</li>
            <li>daasd</li>
            <li>daasd</li>          
          </div>
        </div>
        <div class='contenedor'>
        <div class="split2 left2">
            <br />
            <p class='general_txt2'>2022-01 </p>
            <p class='general_txt2'>- actualmente</p>
          </div>
          <div class="split2 right2">
            <h2 class='decrip_title2'>Desarrollador de software</h2>
            <p class="title2">Mainsoft ltda Bogotá D.C</p>
            <p >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
            <li>daasd</li>
            <li>daasd</li>

          </div>
        </div>
      </div>
    </>
  )
}

export default App
